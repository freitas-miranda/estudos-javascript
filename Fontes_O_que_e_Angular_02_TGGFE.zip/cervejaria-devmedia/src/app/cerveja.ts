export class Cerveja {
    id: number;
    nome: string;
    ibu: number;
    cor: string;
}
